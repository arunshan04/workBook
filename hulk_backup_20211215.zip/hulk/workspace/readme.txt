To install dependencies in requirements.txt in terminal run: 

Pip3 install -r requirements.txt