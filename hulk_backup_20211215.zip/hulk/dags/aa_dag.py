from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from airflow.models import Variable

local_tz = pendulum.timezone("Asia/Tehran")

default_args = {
    'owner': 'nga',
    'depends_on_past': False,
    'start_date': datetime(2020, 10, 10, tzinfo=local_tz),
    'email': ['ngaaje@gmail.com'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}
dag = DAG(dag_id='aatestshow_dag',
          default_args=default_args,
          catchup=False,
          schedule_interval="0 * * * *")
pyspark_app_home = Variable.get("PYSPARK_APP_HOME")

testshow = SparkSubmitOperator(task_id='testshow',
                                              conn_id='spark_local',
                                              application=f'{pyspark_app_home}/spark/testo.py',
                                              total_executor_cores=1,
                                              execution_timeout=timedelta(minutes=10),
                                              dag=dag
                                              )

testshow2 = SparkSubmitOperator(task_id='testshow2',
                                              conn_id='spark_local',
                                              application=f'{pyspark_app_home}/spark/testo.py',
                                              total_executor_cores=1,
                                              execution_timeout=timedelta(minutes=10),
                                              dag=dag
                                              )
testshow>>testshow2
