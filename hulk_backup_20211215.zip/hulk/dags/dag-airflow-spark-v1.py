import airflow
from datetime import datetime, timedelta
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator

default_args = {
    'owner': 'Arun',
    'start_date': datetime(2021, 12, 12),
    'retries': 0,
	  'retry_delay': timedelta(minutes=1)
}
with airflow.DAG('spark_test',
                  default_args=default_args,
                  ) as dag:
    task_elt_documento_pagar = SparkSubmitOperator(
        task_id='elt_spark',
        conn_id='sparkCluster',
        application="dags/testo.py",
        total_executor_cores=2,
        executor_memory="2g",
        conf={
            "spark.driver.maxResultSize": "2g"
        },
    )

