import pyspark
from pyspark.sql import SparkSession
import time
spark = SparkSession. \
    builder. \
    appName("testApplication").getOrCreate()
#    master("spark://spark-master:7077"). \
#    config("spark.executor.memory", "2gb"). \
#    getOrCreate()

#time.sleep(300)
df = spark.read.csv("/opt/workspace/data/uk-macroeconomic-data.csv", header="true")
df.show()
print('HI ****************************************************')
df.count()
#time.sleep(60)
