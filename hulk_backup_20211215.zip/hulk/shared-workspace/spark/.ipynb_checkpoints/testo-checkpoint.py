import pyspark
from pyspark.sql import SparkSession
spark = SparkSession. \
    builder. \
    appName("pyspark-notebook"). \
    master("spark://spark-master:7077"). \
    config("spark.executor.memory", "9gb"). \
    getOrCreate()
df = spark.read.csv("New_testdata.csv", header="true")
df.show()